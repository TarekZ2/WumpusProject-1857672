This Project was written using Qt (for the GUI).
It won't run unless you have the Qt library on your Computer(and the Qt directory is set correctly, do this in the CMAKE.txt in the second line)
Also if you run this you will have to edit the  path variables in the update GUI function of the MainWindow class( line 270ff)
and the generateGUI function (line 330ff). You will have to set the part I called "pathToGraphicsFolder"
to the path of the Graphics folder on your Computer
The .exe in the Wumpus.exe config folder will work without you doing anything
The Project is in the WumpusProject folder. The ui_mainwindow.h isn't necessary for running the programm, but here to understand how its working.
If you have any questions EMail tarek.zwick@gmail.com to contact the support :)