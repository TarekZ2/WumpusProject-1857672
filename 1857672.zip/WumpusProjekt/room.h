#ifndef ROOM_H
#define ROOM_H

#include <vector>


class Room
{
private:
    int roomProperty; // Gold, Wumpus, Pit or nothing
    bool wumpusNearby;
    bool pitNearby;
    bool goldNearby;
    int xRoom; // room coordinates
    int yRoom;
    bool known; // true when the Room allready has been visited

public:
    Room(int roomProperty, int x, int y);
    Room();
    int getRoomProperty() const;
    void setRoomProperty(int newRoomProperty);
    void adjacenceAdd(int newAdjacence); //adds Adjacencies, i.e. wumpus nearby ...
    int getXRoom() const;
    void setXRoom(int newXRoom);
    int getYRoom() const;
    void setYRoom(int newYRoom);
    bool getKnown() const;
    void setKnown(bool newKnown);
    bool getWumpusNearby() const;
    bool getPitNearby() const;
    bool getGoldNearby() const;
    void resetAdjacencies();
};

#endif // ROOM_H
