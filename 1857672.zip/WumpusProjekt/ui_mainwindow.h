/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow //this one is auto generatet. I tried to edit in here, but the way the Qt Environment works prevents this. The changes are overwritten when compiling.
{                   // I didn't design all of this in the Qt Designer tool tho, the ui file that generates this is writen in xml, and it is possible to code there
                    // also the contents of the gameView are all generated in the MainWindow class. Fully in C++
                    //also every change of an Object in this class is done in the MainWindow class.
public:
    QWidget *widget;
    QGridLayout *gridLayout_2;
    QStackedWidget *mainWidget;
    QWidget *WumpusMenu;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QSpinBox *sizeAdjustor;
    QCheckBox *playerTwoCheckBox;
    QCheckBox *collectorModeCheckBox;
    QCheckBox *NPCCeckbox;
    QPushButton *startButton;
    QLabel *label;
    QCheckBox *respawnCheckBox;
    QWidget *WumpusGame;
    QGridLayout *gameGrid;
    QSlider *scaleSlider;
    QLabel *label_2;
    QPushButton *showButton;
    QLabel *pointLabel;
    QPushButton *finishButton;
    QLabel *playerOneLastRoomEvent;
    QGraphicsView *gameWindow;
    QLabel *playerTwoCurrentPoints;
    QLabel *playerTwoLastRoomEvent;
    QLabel *currentPlayerLabel;
    QPushButton *upButton;
    QPushButton *leftButton;
    QPushButton *downButton;
    QPushButton *rightButton;
    QWidget *DefeatScreen;
    QHBoxLayout *horizontalLayout;
    QGridLayout *defeatGrid;
    QPushButton *retryButton;
    QLabel *gameOverPoints;
    QLabel *statusLabel;
    QLabel *playerTwoPoints;
    QLabel *autoPlayerPoints;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow) // this one generates all the UI parts defined in the ui file
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(900, 618);
        widget = new QWidget(MainWindow);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        gridLayout_2 = new QGridLayout(widget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        mainWidget = new QStackedWidget(widget);
        mainWidget->setObjectName(QString::fromUtf8("mainWidget"));
        sizePolicy.setHeightForWidth(mainWidget->sizePolicy().hasHeightForWidth());
        mainWidget->setSizePolicy(sizePolicy);
        mainWidget->setAutoFillBackground(true);
        WumpusMenu = new QWidget();
        WumpusMenu->setObjectName(QString::fromUtf8("WumpusMenu"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(WumpusMenu->sizePolicy().hasHeightForWidth());
        WumpusMenu->setSizePolicy(sizePolicy1);
        layoutWidget = new QWidget(WumpusMenu);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 0, 231, 281));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        sizeAdjustor = new QSpinBox(layoutWidget);
        sizeAdjustor->setObjectName(QString::fromUtf8("sizeAdjustor"));
        QFont font;
        font.setPointSize(16);
        sizeAdjustor->setFont(font);
        sizeAdjustor->setMinimum(5);
        sizeAdjustor->setMaximum(50);

        gridLayout->addWidget(sizeAdjustor, 1, 0, 1, 1);

        playerTwoCheckBox = new QCheckBox(layoutWidget);
        playerTwoCheckBox->setObjectName(QString::fromUtf8("playerTwoCheckBox"));

        gridLayout->addWidget(playerTwoCheckBox, 3, 0, 1, 1);

        collectorModeCheckBox = new QCheckBox(layoutWidget);
        collectorModeCheckBox->setObjectName(QString::fromUtf8("collectorModeCheckBox"));

        gridLayout->addWidget(collectorModeCheckBox, 4, 0, 1, 1);

        NPCCeckbox = new QCheckBox(layoutWidget);
        NPCCeckbox->setObjectName(QString::fromUtf8("NPCCeckbox"));

        gridLayout->addWidget(NPCCeckbox, 2, 0, 1, 1);

        startButton = new QPushButton(layoutWidget);
        startButton->setObjectName(QString::fromUtf8("startButton"));
        startButton->setEnabled(true);
        QFont font1;
        font1.setPointSize(12);
        startButton->setFont(font1);

        gridLayout->addWidget(startButton, 6, 0, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);
        label->setFont(font);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        respawnCheckBox = new QCheckBox(layoutWidget);
        respawnCheckBox->setObjectName(QString::fromUtf8("respawnCheckBox"));

        gridLayout->addWidget(respawnCheckBox, 5, 0, 1, 1);

        mainWidget->addWidget(WumpusMenu);
        WumpusGame = new QWidget();
        WumpusGame->setObjectName(QString::fromUtf8("WumpusGame"));
        WumpusGame->setEnabled(true);
        sizePolicy.setHeightForWidth(WumpusGame->sizePolicy().hasHeightForWidth());
        WumpusGame->setSizePolicy(sizePolicy);
        gameGrid = new QGridLayout(WumpusGame);
        gameGrid->setObjectName(QString::fromUtf8("gameGrid"));
        scaleSlider = new QSlider(WumpusGame);
        scaleSlider->setObjectName(QString::fromUtf8("scaleSlider"));
        sizePolicy2.setHeightForWidth(scaleSlider->sizePolicy().hasHeightForWidth());
        scaleSlider->setSizePolicy(sizePolicy2);
        scaleSlider->setValue(33);
        scaleSlider->setSliderPosition(33);
        scaleSlider->setOrientation(Qt::Horizontal);

        gameGrid->addWidget(scaleSlider, 12, 0, 1, 1);

        label_2 = new QLabel(WumpusGame);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gameGrid->addWidget(label_2, 11, 0, 1, 2);

        showButton = new QPushButton(WumpusGame);
        showButton->setObjectName(QString::fromUtf8("showButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(showButton->sizePolicy().hasHeightForWidth());
        showButton->setSizePolicy(sizePolicy3);

        gameGrid->addWidget(showButton, 13, 0, 1, 1);

        pointLabel = new QLabel(WumpusGame);
        pointLabel->setObjectName(QString::fromUtf8("pointLabel"));
        sizePolicy3.setHeightForWidth(pointLabel->sizePolicy().hasHeightForWidth());
        pointLabel->setSizePolicy(sizePolicy3);

        gameGrid->addWidget(pointLabel, 0, 0, 1, 1);

        finishButton = new QPushButton(WumpusGame);
        finishButton->setObjectName(QString::fromUtf8("finishButton"));

        gameGrid->addWidget(finishButton, 13, 1, 1, 1);

        playerOneLastRoomEvent = new QLabel(WumpusGame);
        playerOneLastRoomEvent->setObjectName(QString::fromUtf8("playerOneLastRoomEvent"));
        sizePolicy2.setHeightForWidth(playerOneLastRoomEvent->sizePolicy().hasHeightForWidth());
        playerOneLastRoomEvent->setSizePolicy(sizePolicy2);

        gameGrid->addWidget(playerOneLastRoomEvent, 0, 1, 1, 2);

        gameWindow = new QGraphicsView(WumpusGame);
        gameWindow->setObjectName(QString::fromUtf8("gameWindow"));
        sizePolicy1.setHeightForWidth(gameWindow->sizePolicy().hasHeightForWidth());
        gameWindow->setSizePolicy(sizePolicy1);
        gameWindow->setBaseSize(QSize(0, 0));
        gameWindow->setAutoFillBackground(false);
        gameWindow->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);

        gameGrid->addWidget(gameWindow, 0, 3, 14, 1);

        playerTwoCurrentPoints = new QLabel(WumpusGame);
        playerTwoCurrentPoints->setObjectName(QString::fromUtf8("playerTwoCurrentPoints"));
        sizePolicy3.setHeightForWidth(playerTwoCurrentPoints->sizePolicy().hasHeightForWidth());
        playerTwoCurrentPoints->setSizePolicy(sizePolicy3);

        gameGrid->addWidget(playerTwoCurrentPoints, 1, 0, 1, 1);

        playerTwoLastRoomEvent = new QLabel(WumpusGame);
        playerTwoLastRoomEvent->setObjectName(QString::fromUtf8("playerTwoLastRoomEvent"));
        sizePolicy2.setHeightForWidth(playerTwoLastRoomEvent->sizePolicy().hasHeightForWidth());
        playerTwoLastRoomEvent->setSizePolicy(sizePolicy2);

        gameGrid->addWidget(playerTwoLastRoomEvent, 1, 1, 1, 2);

        currentPlayerLabel = new QLabel(WumpusGame);
        currentPlayerLabel->setObjectName(QString::fromUtf8("currentPlayerLabel"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(currentPlayerLabel->sizePolicy().hasHeightForWidth());
        currentPlayerLabel->setSizePolicy(sizePolicy4);

        gameGrid->addWidget(currentPlayerLabel, 2, 0, 1, 2);

        upButton = new QPushButton(WumpusGame);
        upButton->setObjectName(QString::fromUtf8("upButton"));
        sizePolicy2.setHeightForWidth(upButton->sizePolicy().hasHeightForWidth());
        upButton->setSizePolicy(sizePolicy2);

        gameGrid->addWidget(upButton, 5, 1, 1, 1);

        leftButton = new QPushButton(WumpusGame);
        leftButton->setObjectName(QString::fromUtf8("leftButton"));
        sizePolicy2.setHeightForWidth(leftButton->sizePolicy().hasHeightForWidth());
        leftButton->setSizePolicy(sizePolicy2);

        gameGrid->addWidget(leftButton, 6, 0, 1, 1);

        downButton = new QPushButton(WumpusGame);
        downButton->setObjectName(QString::fromUtf8("downButton"));
        sizePolicy2.setHeightForWidth(downButton->sizePolicy().hasHeightForWidth());
        downButton->setSizePolicy(sizePolicy2);

        gameGrid->addWidget(downButton, 7, 1, 1, 1);

        rightButton = new QPushButton(WumpusGame);
        rightButton->setObjectName(QString::fromUtf8("rightButton"));

        gameGrid->addWidget(rightButton, 6, 2, 1, 1);

        mainWidget->addWidget(WumpusGame);
        DefeatScreen = new QWidget();
        DefeatScreen->setObjectName(QString::fromUtf8("DefeatScreen"));
        horizontalLayout = new QHBoxLayout(DefeatScreen);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        defeatGrid = new QGridLayout();
        defeatGrid->setObjectName(QString::fromUtf8("defeatGrid"));
        retryButton = new QPushButton(DefeatScreen);
        retryButton->setObjectName(QString::fromUtf8("retryButton"));

        defeatGrid->addWidget(retryButton, 4, 0, 1, 1);

        gameOverPoints = new QLabel(DefeatScreen);
        gameOverPoints->setObjectName(QString::fromUtf8("gameOverPoints"));

        defeatGrid->addWidget(gameOverPoints, 1, 0, 1, 1);

        statusLabel = new QLabel(DefeatScreen);
        statusLabel->setObjectName(QString::fromUtf8("statusLabel"));

        defeatGrid->addWidget(statusLabel, 0, 0, 1, 1);

        playerTwoPoints = new QLabel(DefeatScreen);
        playerTwoPoints->setObjectName(QString::fromUtf8("playerTwoPoints"));

        defeatGrid->addWidget(playerTwoPoints, 2, 0, 1, 1);

        autoPlayerPoints = new QLabel(DefeatScreen);
        autoPlayerPoints->setObjectName(QString::fromUtf8("autoPlayerPoints"));

        defeatGrid->addWidget(autoPlayerPoints, 3, 0, 1, 1);


        horizontalLayout->addLayout(defeatGrid);

        mainWidget->addWidget(DefeatScreen);

        gridLayout_2->addWidget(mainWidget, 0, 1, 1, 1);

        MainWindow->setCentralWidget(widget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 900, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        mainWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow) // this one sets all the texts. the reason this is seperated  is, that u technically could implement different language options. which I didn't
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        playerTwoCheckBox->setText(QCoreApplication::translate("MainWindow", "second Player", nullptr));
        collectorModeCheckBox->setText(QCoreApplication::translate("MainWindow", "Collector Mode (collect all the Gold)", nullptr));
        NPCCeckbox->setText(QCoreApplication::translate("MainWindow", "automatic Player", nullptr));
        startButton->setText(QCoreApplication::translate("MainWindow", "START", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Boardsize:", nullptr));
        respawnCheckBox->setText(QCoreApplication::translate("MainWindow", "Respawn", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Change Scale of Board:", nullptr));
        showButton->setText(QCoreApplication::translate("MainWindow", "show All", nullptr));
        pointLabel->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p>0 Punkte</p></body></html>", nullptr));
        finishButton->setText(QCoreApplication::translate("MainWindow", "Finish Game", nullptr));
        playerOneLastRoomEvent->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600; color:#c6c128;\">GOLD COLLECTED!</span></p></body></html>", nullptr));
        playerTwoCurrentPoints->setText(QCoreApplication::translate("MainWindow", "0 Punkte", nullptr));
        playerTwoLastRoomEvent->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600; color:#e1e155;\">GOLD COLLECTED!</span></p><p><br/></p><p><span style=\" font-size:10pt;\"><br/></span></p></body></html>", nullptr));
        currentPlayerLabel->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        upButton->setText(QCoreApplication::translate("MainWindow", "UP", nullptr));
#if QT_CONFIG(shortcut) //also this sets the shortcuts I used to implement WASD movement. If these keys are pressed, the system emits the same signal thats emitted on button press
        upButton->setShortcut(QCoreApplication::translate("MainWindow", "W", nullptr));
#endif // QT_CONFIG(shortcut)
        leftButton->setText(QCoreApplication::translate("MainWindow", "LEFT", nullptr));
#if QT_CONFIG(shortcut)
        leftButton->setShortcut(QCoreApplication::translate("MainWindow", "A", nullptr));
#endif // QT_CONFIG(shortcut)
        downButton->setText(QCoreApplication::translate("MainWindow", "DOWN", nullptr));
#if QT_CONFIG(shortcut)
        downButton->setShortcut(QCoreApplication::translate("MainWindow", "S", nullptr));
#endif // QT_CONFIG(shortcut)
        rightButton->setText(QCoreApplication::translate("MainWindow", "RIGHT", nullptr));
#if QT_CONFIG(shortcut)
        rightButton->setShortcut(QCoreApplication::translate("MainWindow", "D", nullptr));
#endif // QT_CONFIG(shortcut)
        retryButton->setText(QCoreApplication::translate("MainWindow", "RETRY", nullptr));
        gameOverPoints->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        statusLabel->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:36pt;\">GAME OVER</span></p></body></html>", nullptr));
        playerTwoPoints->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        autoPlayerPoints->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
