﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "board.h"
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <QObject>
#include <QGridLayout>
#include <QEvent>
#include <QLabel>
#include <QGraphicsProxyWidget>
#include "LocalPlayer.h"
#include "automaticplayer.h"
#include <QCoreApplication>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots: // all of these are triggered through GUI interaction


    void on_startButton_clicked(); // starts the Game

    void on_leftButton_clicked(); //current Player moves left

    void on_rightButton_clicked(); // pretty sure you can guess this one

    void on_upButton_clicked();

    void on_downButton_clicked();

    void on_retryButton_clicked(); // triggers the retry cleanup and makes it possible to start another round

    void on_showButton_clicked(); //show/hide all unknown rooms

    void on_scaleSlider_sliderMoved(int position); //zoom



    void on_finishButton_clicked(); // allows you to jump to the end screen and get a winner without having to get the winning condition

private:
    Ui::MainWindow *ui; // this is the actual gui, which is writen in xml. Partially created automaticaly using a Design editor, partially by me
    LocalPlayer *PlayerOne;              //the xml actually creates a  .h, but it gets overwriten by the xml and cant write in the xml, so no c++ gui design there :(. Partially in the mainwindow.h tho
    void updatePoints();
    QGraphicsScene * gameScene = new QGraphicsScene; // The Graphicsscene in which the game is animated. Basically a container that includes all important things
    void roomEvent(int i, Player *thisPlayer); // is called when stepped on a special Room
    void retry(); // manages the necessary memorycleaning so the game can be startet agein
    void updateGUI(bool drawAll, bool seeAll, Player *thisPlayer);// calls all the GUI updates necessary to display changes
    void updateRooms(bool drawAll, bool seeAll, Player *thisPlayer); // updates the needed RoomGraphics, it can be choosen which ones are needed and which you want to see
    void updatePlayerPosition(Player *thisPlayer);
    int scale;// used for the scalation of the GUI
    QLabel *playerOnePicture = new QLabel(); // the Label which displays PlayerOne
    QGraphicsProxyWidget *proxy1 = new QGraphicsProxyWidget; //this is necessary to add or remove the playerOnePicture
    bool autoPlayer;
    void nextPlayer(); // controll over the next Player instance is given, also activates the autoplayermovement
    int currentPlayer; // holds a value depending on whos turn it is
    automaticPlayer* autoPlayerOne;
    QLabel *autoPlayerPicture = new QLabel();
    QGraphicsProxyWidget *autoProxy = new QGraphicsProxyWidget;
    void generateGUI(); // generates the GUI when the game is started
    LocalPlayer* PlayerTwo;
    QGraphicsProxyWidget *playerTwoProxy = new QGraphicsProxyWidget;
    QLabel *playerTwoPicture = new QLabel;
    bool secondPlayer;
    void updatePlayerState();
    bool collectorMode;
    bool respawnOn;
    void setGameResults(int i, Player* thisPlayer, bool winByPoints);
    bool shown;
    QPalette playerOnePalette;
    QPalette playerTwoPalette;
    bool gameEnd;
    int  eventTimerPlayerOne; // needed so the event labels dissapear after a certain time
    int eventTimerPlayerTwo;






};
#endif // MAINWINDOW_H
