#ifndef AUTOMATICPLAYER_H
#define AUTOMATICPLAYER_H

#include "player.h"
#include <math.h>


class automaticPlayer: public Player
{
public:
    automaticPlayer();
    automaticPlayer(Board *thisBoard, int scanRange);
    void autoMove(); // movement function of the autoPlayer
private:
    Room* analyzedRoom;
    float expandetRating(Room* callingRoom,int x, int y, int depthOfAnalysis); // rates the different directions
    void moveRandom(bool dir1, bool dir2, bool dir3, bool dir4); // move Random in one of the given directions
    int scanRange;
    int step; //needet for anti stuck mechanic
    int xTwoSteps;//needet for anti stuck mechanic
    int yTwoSteps; //needet for anti stuck mechanic
    int stuck; // guess what? needet for anti stuck mechanic
    bool nearbyKnown(Room* thisRoom); // gets if the given Room has more than one known Adjacent Rooms
    bool nearbyPit(Room* thisRoom); //gets if theres a pit near the given Room
    bool nearbyWumpus(Room* thisRoom); // same as nearbyPit
    bool allKnown; // needet for different anti stuck mechanic
    Room* lastRoom;
};

#endif // AUTOMATICPLAYER_H
