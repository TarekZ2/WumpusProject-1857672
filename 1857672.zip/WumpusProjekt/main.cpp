#include <QApplication>
#include"mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show(); // this sequence calls the mainwindow and loops it. this is necessary for communication with the GUI, even tho this isn't really the standard of most programs
    return a.exec();





}
